import { localStorage } from "./ls.js";

const ls = new localStorage();

let caught = [];

export class caughtMon {
    constructor (pokemon) {
        this.pokemonName = pokemonName;
        this.collected = {pokemon: this.pokemonName};
    }
    saveCollected(k, v) {
        ls.set(k, v);
    }
    getCollected(k) {
        let lastSave = ls.get(k);
        return lastSave;
    }
    newCollected() {
        caught.push(this.collected);
        this.saveCollected("caughtMon", caught);
    }
    removeCollected() {
        this.caught.splice(i, 1);
        ls.saveCollected("caughtMon", caught);
    }

}