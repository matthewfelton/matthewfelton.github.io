//import { caughtMon } from "./caught";
//const caught = new caughtMon;

const pokemonList = [];
const apiArray =[];
let api = "";
for (let i = 1; i <= 150; i++) {
    let api = `https://pokeapi.co/api/v2/pokemon/${i}`
    apiArray.push(fetch(api)
    .then(res => res.json()));
}
Promise.all(apiArray)
.then((results) => {
    //console.log(results);
    results.forEach((data) => {
        //console.log(data);
        pokemonList.push(
            {
                id: data.id,
                name: data.name,
                image: data.sprites["front_default"],
                caught: false,
                type: data.types.map((type) => type.type.name).join(', ')
                
            }
        )
        
    })
});
console.log(pokemonList);

export class pokemonjs {
    constructor() {
        this.fullList = [pokemonList];
        this.caughtList = [];
        this.uncaughtList = [];
    }





}
console.log(fullList);