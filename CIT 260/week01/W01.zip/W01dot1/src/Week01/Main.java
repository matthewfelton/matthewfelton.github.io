package Week01;

public class Main {

    public static void main(String[] args) {
	//Displays my name,class and section, location, and favorite dessert using system println
        System.out.println("Matthew Felton");
        System.out.println("CIT260-01");
        System.out.println("Athens, Alabama");
        System.out.println("Fried Bananas");
    }
}
